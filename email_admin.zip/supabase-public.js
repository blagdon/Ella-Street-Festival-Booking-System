/**
 * supabase-public.js
 * Single source of truth for Supabase credentials on PUBLIC-FACING pages.
 * Used by: General_Booking.html, Food_Stall_booking.html, cancel_booking.html
 *
 * This is the anon (public) key — it is designed to be client-facing.
 * Security is enforced by Row Level Security (RLS) on the Supabase tables,
 * NOT by hiding this key.
 *
 * IMPORTANT: Ensure RLS is enabled on all tables in the Supabase dashboard.
 * See security-audit.md for required policies.
 */

const ESF_PUBLIC_CONFIG = {
    SUPABASE_URL: "https://rsnxhuhibglieofikkpo.supabase.co",
    SUPABASE_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJzbnhodWhpYmdsaWVvZmlra3BvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2Nzg5MjcsImV4cCI6MjA4NTI1NDkyN30.QNrMVCc9FFdIAR4wRv6g4V4p2JA8pbCoaf8zLRuu0fw",
    BUCKET_NAME: "esf-documents",
    TURNSTILE_SITE_KEY: "0x4AAAAAACZTfDIHzMhGqnER"
};

/**
 * Creates and returns a Supabase client using the public config.
 * Caches the client so it's only created once per page.
 */
let _publicSbClient = null;
function getPublicSupabaseClient() {
    if (!_publicSbClient) {
        if (typeof supabase === 'undefined') {
            throw new Error("Supabase JS library not loaded. Check your script tags.");
        }
        _publicSbClient = supabase.createClient(
            ESF_PUBLIC_CONFIG.SUPABASE_URL,
            ESF_PUBLIC_CONFIG.SUPABASE_KEY
        );
    }
    return _publicSbClient;
}
