import { getSupabaseClient } from './supabase.js';
import { CONFIG, getStallCost } from './config.js';
import { escapeHtml } from './ui.js';

const TBL_BOOKINGS = 'bookings';
const TBL_PAYMENTS = 'payments';
const TBL_LOCATIONS = 'locations';
const TBL_EMAIL_QUEUE = 'email_queue';
const TBL_AUDIT_LOGS = 'audit_logs';

/**
 * Validates a string length.
 */
function validateString(val, maxLen) {
    if (val === null || val === undefined) return '';
    const s = String(val);
    if (s.length > maxLen) throw new Error(`Input exceeds maximum length of ${maxLen} characters.`);
    return s;
}

/**
 * Validates an email format.
 */
function validateEmail(val) {
    const s = validateString(val, 254);
    if (s && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) throw new Error('Invalid email format.');
    return s;
}


/**
 * Validates a booking ID format.
 * @param {string} id 
 */
function validateBookingId(id) {
    if (!id || typeof id !== 'string') throw new Error('Missing booking ID.');
    // ID Format: ESF26-(DEV|FOOD|NONFOOD|MISC)-XXXX
    if (!/^ESF26-(DEV|FOOD|NONFOOD|MISC)-\d+/.test(id)) {
        console.warn("Invalid ID format detected:", id); // Warn but maybe allow if it's a legacy ID? 
        // For now, let's strictly enforce or at least match the config.js logic
        throw new Error(`Invalid Booking ID format: ${id}`);
    }
}

/**
 * Validates a status string.
 * @param {string} status 
 */
function validateStatus(status) {
    const valid = ['Pending', 'Confirmed', 'Rejected', 'Cancelled', 'On Hold', 'HCC Checks'];
    if (!valid.includes(status)) throw new Error("Invalid Status");
}

/**
 * Fetches Kanban board data.
 * @param {string} currentInstance 
 * @returns {Promise<Array>}
 */
export async function fetchKanbanData(currentInstance) {
    const sb = getSupabaseClient();
    const prefix = CONFIG.INSTANCE_MAP[currentInstance] || 'ESF26-DEV-';

    const { data, error } = await sb
        .from(TBL_BOOKINGS)
        .select('*')
        .eq('instance_prefix', prefix)
        .order('created_at', { ascending: false });

    if (error) throw error;
    return data || []; // Raw data, adaptation can happen in UI if needed
}

/**
 * Updates a booking status.
 * @param {string} id 
 * @param {string} status 
 * @param {string} reason 
 */
export async function updateBookingStatus(id, status, reason = null) {
    validateBookingId(id);
    validateStatus(status);
    const sb = getSupabaseClient();

    const updateFields = { status: status };
    if (status !== 'Confirmed') updateFields.location_id = null;
    if (reason) updateFields.rejection_reason = reason;

    const { error } = await sb.from(TBL_BOOKINGS).update(updateFields).eq('id', id);
    if (error) throw error;

    // Audit log could vary, but for now we skip complex audit logging or implement a simple one if needed
    // Assuming auditLog is a separate concern or we can add it here later
    return { status: 'success' };
}

/**
 * Adds an admin note to a booking.
 * @param {string} id 
 * @param {string} note 
 */
export async function addNote(id, note) {
    validateBookingId(id);
    const sb = getSupabaseClient();
    const { error } = await sb.from(TBL_BOOKINGS).update({ admin_notes: note }).eq('id', id);
    if (error) throw error;
    return { status: 'success' };
}

/**
 * Queues an email in the database.
 * @param {string} id 
 * @param {string} subject 
 * @param {string} body 
 */
export async function sendEmail(id, subject, body) {
    validateBookingId(id);
    const sb = getSupabaseClient();

    // Fetch email and instance prefix
    const { data: emailData, error: fetchErr } = await sb
        .from(TBL_BOOKINGS)
        .select('email, instance_prefix')
        .eq('id', id)
        .single();

    if (fetchErr || !emailData || !emailData.email) throw new Error("Could not find email address.");

    const { error } = await sb.from(TBL_EMAIL_QUEUE).insert({
        recipient: emailData.email,
        subject: subject,
        body: body,
        status: 'Pending',
        instance_prefix: emailData.instance_prefix
    });

    if (error) throw error;
    return { status: 'success', message: 'Email queued.' };
}

/**
 * Finalizes a confirmation (handles payments logic).
 * @param {string} id 
 * @param {boolean} isChargeable 
 * @param {object|null} providedSnapshot - Optional booking snapshot to avoid redundant DB call
 * @param {number|null} overrideCost - Optional admin-specified cost override
 */
export async function finalizeConfirmation(id, isChargeable, providedSnapshot = null, overrideCost = null) {
    validateBookingId(id);
    const sb = getSupabaseClient();

    let bSnapshot = providedSnapshot;

    if (!bSnapshot) {
        const { data, error: snapError } = await sb
            .from(TBL_BOOKINGS)
            .select('instance_prefix, business_name, owner_name, email, phone, stall_type, stall_cost')
            .eq('id', id)
            .single();

        if (snapError || !data) {
            throw new Error(`Failed to fetch booking snapshot for ID ${id}: ${snapError ? snapError.message : 'Record not found'}`);
        }
        bSnapshot = data;
    }

    const prefix = bSnapshot.instance_prefix || "GENERAL";
    const confirmDate = new Date().toISOString();

    // Ensure status is confirmed (redundant safety)
    await sb.from(TBL_BOOKINGS).update({ status: 'Confirmed', date_confirmed: confirmDate }).eq('id', id);

    if (isChargeable) {
        // Priority: 1. Admin override, 2. Booking's stored cost, 3. Config default
        let cost = 0;
        if (overrideCost !== null && !isNaN(overrideCost)) {
            cost = overrideCost;
        } else if (bSnapshot.stall_cost !== undefined && bSnapshot.stall_cost !== null) {
            cost = parseFloat(bSnapshot.stall_cost);
        } else {
            cost = getStallCost(prefix);
        }

        // Save the final cost back to the booking record
        await sb.from(TBL_BOOKINGS).update({ stall_cost: cost }).eq('id', id);

        await sb.from(TBL_PAYMENTS).upsert({
            booking_id: id,
            stall_cost: cost,
            paid: false,
            instance_prefix: prefix,
            business_name: bSnapshot.business_name,
            owner_name: bSnapshot.owner_name,
            email: bSnapshot.email,
            phone: bSnapshot.phone,
            stall_type: bSnapshot.stall_type,
            date_confirmed: confirmDate
        }, { onConflict: 'booking_id', ignoreDuplicates: false });
    } else {
        await sb.from(TBL_PAYMENTS).delete().eq('booking_id', id);
    }

    return { status: 'success' };
}

/**
 * Fetches bookings and joins with payment data.
 * @param {string} currentInstance 
 */
export async function fetchPayments(currentInstance) {
    const sb = getSupabaseClient();
    let instanceFilter = (currentInstance === 'DEV') ? ['ESF26-DEV-'] : ['ESF26-FOOD-', 'ESF26-NONFOOD-'];
    if (currentInstance === 'FOOD') instanceFilter = ['ESF26-FOOD-'];
    // Logic for 'GENERAL' or 'MISC' needs to be consistent. 
    // config.js had: (CURRENT_INSTANCE === 'DEV') ? ['ESF26-DEV-'] : ['ESF26-FOOD-', 'ESF26-NONFOOD-'];
    // It didn't seem to account for a user being logged in as just FOOD or just GENERAL properly if they were restricted? 
    // But let's assume the user has access to what the instance implies.
    // However, for safety, let's replicate config.js logic but slightly better if possible.
    // config.js logic: let paymentFilter = (CURRENT_INSTANCE === 'DEV') ? ['ESF26-DEV-'] : ['ESF26-FOOD-', 'ESF26-NONFOOD-'];

    const { data: bookings, error: bErr } = await sb
        .from(TBL_BOOKINGS)
        .select('*')
        .in('instance_prefix', instanceFilter);
    if (bErr) throw bErr;

    const { data: payments, error: pErr } = await sb
        .from(TBL_PAYMENTS)
        .select('*');
    if (pErr) throw pErr;

    const payMap = new Map(payments.map(p => [p.booking_id, p]));

    // Filter bookings to only those that HAVE a payment record (chargeable ones)
    return bookings.filter(b => payMap.has(b.id)).map(b => {
        const p = payMap.get(b.id);
        return {
            ...b,
            stall_cost: p.stall_cost,
            paid: p.paid,
            date_paid: p.date_paid,
            bank_ref: p.bank_ref,
            editor: p.editor,
            // business is already in b, but p might have snapshot. We prefer b (live booking data) or p (snapshot)?
            // config.js used ...b and overwrites with p fields. 
        };
    });
}

/**
 * Updates a payment record.
 * @param {object} payload 
 */
export async function updatePayment(payload) {
    validateBookingId(payload.booking_id);
    const sb = getSupabaseClient();
    const { error } = await sb.from(TBL_PAYMENTS).update({
        paid: payload.paid === true,
        date_paid: payload.date_paid || null,
        bank_ref: payload.bank_ref,
        editor: payload.editor
    }).eq('booking_id', payload.booking_id);

    if (error) throw error;
    return { status: 'success' };
}

/**
 * Fetches location data including bookings, locations, and global occupancy.
 * @param {string} currentInstance 
 */
export async function fetchLocationData(currentInstance) {
    const sb = getSupabaseClient();
    const currentPrefix = (currentInstance === 'FOOD') ? 'ESF26-FOOD-' :
        (currentInstance === 'GENERAL') ? 'ESF26-NONFOOD-' :
            (currentInstance === 'MISC') ? 'ESF26-MISC-' : 'ESF26-DEV-';

    // 1. Fetch bookings to DISPLAY (Current Instance Only)
    const { data: bLocs, error: blErr } = await sb
        .from(TBL_BOOKINGS)
        .select('*')
        .eq('status', 'Confirmed')
        .eq('instance_prefix', currentPrefix);
    if (blErr) throw blErr;

    // 2. Fetch GLOBAL Occupancy
    let occupancyFilter = [];
    if (currentPrefix === 'ESF26-DEV-') {
        occupancyFilter = ['ESF26-DEV-'];
    } else {
        occupancyFilter = ['ESF26-FOOD-', 'ESF26-NONFOOD-', 'ESF26-MISC-'];
    }

    const { data: allOccupants, error: occErr } = await sb
        .from(TBL_BOOKINGS)
        .select('location_id')
        .eq('status', 'Confirmed')
        .in('instance_prefix', occupancyFilter)
        .neq('location_id', null);
    if (occErr) throw occErr;

    // 3. Get Locations Reference
    const dataset = (currentInstance === 'DEV') ? 'DEV' : 'LIVE';

    let locs = [];
    try {
        const { data: lData } = await sb.from(TBL_LOCATIONS).select('*').eq('dataset', dataset);
        if (lData) locs = lData;
    } catch (e) { }

    return {
        bookings: bLocs,
        locations: locs,
        occupied_ids: allOccupants.map(o => o.location_id)
    };
}

/**
 * Updates a booking's location.
 * @param {string} id 
 * @param {string} locationId 
 */
export async function updateLocation(id, locationId) {
    validateBookingId(id);
    const sb = getSupabaseClient();
    const { error } = await sb.from(TBL_BOOKINGS).update({ location_id: locationId }).eq('id', id);
    if (error) throw error;
    return { status: 'success' };
}

/**
 * Queues a location allocation email.
 * @param {string} id 
 */
export async function queueLocationEmail(id) {
    validateBookingId(id);
    const sb = getSupabaseClient();

    const { data: bLocEmail, error: fErr } = await sb.from(TBL_BOOKINGS).select('email, owner_name, business_name, location_id, instance_prefix').eq('id', id).single();
    if (fErr) throw fErr;
    if (!bLocEmail.location_id) throw new Error("No location assigned.");

    const locSubject = `Stall Location Allocation: ${bLocEmail.business_name}`;
    const locBody = `Dear ${bLocEmail.owner_name},\n\nWe are pleased to confirm your stall location for the festival.\n\nBusiness: ${bLocEmail.business_name}\nAssigned Location: ${bLocEmail.location_id}\n\nPlease refer to the festival map for exact positioning.\n\nRegards,\nThe Festival Team`;

    const { error: qLocErr } = await sb.from(TBL_EMAIL_QUEUE).insert({
        recipient: bLocEmail.email,
        subject: locSubject,
        body: locBody,
        status: 'Pending',
        instance_prefix: bLocEmail.instance_prefix
    });
    if (qLocErr) throw qLocErr;
    return { status: 'success', message: 'Email queued.' };
}

/**
 * Fetches all bookings for statistics.
 * @returns {Promise<Array>}
 */
export async function fetchStatsData() {
    const sb = getSupabaseClient();
    const { data, error } = await sb
        .from(TBL_BOOKINGS)
        .select('*')
        .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
}

/**
 * Fetches map data with joined booking info.
 * @param {string} currentInstance 
 * @returns {Promise<Array>}
 */
export async function fetchMapData(currentInstance) {
    const sb = getSupabaseClient();
    const mapDataset = (currentInstance === 'DEV') ? 'DEV' : 'LIVE';

    // 1. Get Locations
    const { data: mapLocs } = await sb.from(TBL_LOCATIONS).select('*').eq('dataset', mapDataset);
    const safeMapLocs = mapLocs || [];

    // 2. Get Confirmed Bookings
    let bQuery = sb.from(TBL_BOOKINGS)
        .select('id, business_name, description, stall_type, location_id, category, instance_prefix')
        .eq('status', 'Confirmed');

    if (currentInstance === 'DEV') {
        bQuery = bQuery.eq('instance_prefix', 'ESF26-DEV-');
    } else {
        bQuery = bQuery.in('instance_prefix', ['ESF26-FOOD-', 'ESF26-NONFOOD-', 'ESF26-MISC-']);
    }

    const { data: bData, error: mapBErr } = await bQuery;
    if (mapBErr) throw mapBErr;

    // 3. Join Data
    const bookingMap = new Map((bData || []).map(b => [b.location_id, b]));

    return safeMapLocs.map(l => {
        const booking = bookingMap.get(l.id);
        if (!booking) return null;
        return {
            location_id: l.id,
            lat: l.lat,
            lng: l.lng,
            business: booking.business_name,
            description: booking.description,
            stall_type: booking.stall_type,
            category: booking.category,
            is_active: true
        };
    }).filter(item => item !== null);
}

/**
 * Updates booking details.
 * @param {object} payload 
 */
export async function updateBookingDetails(payload) {
    validateBookingId(payload.id);
    const sb = getSupabaseClient();

    const MAX_FIELD_LENGTHS = {
        business: 128, owner: 64, email: 254, phone: 30, category: 64,
        description: 500, house: 256, other: 500
    };

    const { error } = await sb.from(TBL_BOOKINGS).update({
        business_name: validateString(payload.business, MAX_FIELD_LENGTHS.business),
        owner_name: validateString(payload.owner, MAX_FIELD_LENGTHS.owner),
        email: validateEmail(payload.email),
        phone: validateString(payload.phone, MAX_FIELD_LENGTHS.phone),
        category: validateString(payload.category, MAX_FIELD_LENGTHS.category),
        description: validateString(payload.description, MAX_FIELD_LENGTHS.description),
        stall_type: payload.type,
        power_required: payload.power || 'No power',
        address: validateString(payload.house, MAX_FIELD_LENGTHS.house),
        other_requirements: validateString(payload.other, MAX_FIELD_LENGTHS.other),
        is_resident: payload.is_resident === true,
        is_charity: payload.is_charity || 'Commercial'
    }).eq('id', payload.id);

    if (error) throw error;
    await auditLog('update_details', payload.id, { business: payload.business, owner: payload.owner });
    return { status: 'success' };
}

/**
 * Writes to the audit log.
 * @param {string} action 
 * @param {string} targetId 
 * @param {object} details 
 */
export async function auditLog(action, targetId, details = {}) {
    try {
        const sb = getSupabaseClient();
        const { data: { session } } = await sb.auth.getSession();
        const userEmail = session?.user?.email || 'anonymous';

        // Get current instance from local storage if possible, or default
        const currentInstance = (typeof localStorage !== 'undefined' && localStorage.getItem('ESF_INSTANCE')) || 'UNKNOWN';

        await sb.from(TBL_AUDIT_LOGS).insert({
            action: action,
            target_id: targetId || null,
            user_email: userEmail,
            details: details,
            instance: currentInstance
        });
    } catch (e) {
        console.warn('Audit log failed:', e.message);
    }
}
