/**
 * supabase.js
 * Wrapper for Supabase client initialization and authentication.
 */
import { CONFIG } from './config.js';

let _activeSbClient = null;

export function getSupabaseClient() {
    if (_activeSbClient) return _activeSbClient;

    if (typeof supabase === 'undefined') {
        // Fallback if loaded via CDN global
        if (window.supabase) {
            _activeSbClient = window.supabase.createClient(CONFIG.SUPABASE.URL, CONFIG.SUPABASE.KEY);
            return _activeSbClient;
        }
        console.error("Supabase SDK not loaded!");
        throw new Error("Supabase SDK not loaded");
    }

    // If imported as module (future proofing) or global
    const { createClient } = supabase;
    _activeSbClient = createClient(CONFIG.SUPABASE.URL, CONFIG.SUPABASE.KEY);
    return _activeSbClient;
}

/**
 * Checks if the user is authenticated. If not, redirects to login.html.
 */
export async function requireAuth() {
    try {
        const sb = getSupabaseClient();
        const { data: { session } } = await sb.auth.getSession();

        if (!session) {
            window.location.href = 'login.html';
            throw new Error('Not authenticated');
        }

        return session;
    } catch (e) {
        if (e.message !== 'Not authenticated') {
            window.location.href = 'login.html';
        }
        throw e;
    }
}

/**
 * Signs the user out.
 */
export async function signOut() {
    const sb = getSupabaseClient();
    await sb.auth.signOut();
    window.location.href = 'login.html';
}
