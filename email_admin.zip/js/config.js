/**
 * config.js
 * Central configuration constants for the application.
 */

export const CONFIG = {
    // Database Prefixes (Strictly enforces data separation)
    INSTANCE_MAP: {
        'DEV': 'ESF26-DEV-',
        'FOOD': 'ESF26-FOOD-',
        'GENERAL': 'ESF26-NONFOOD-', // 'General' maps to Non-Food data
        'MISC': 'ESF26-MISC-'        // 'MISC' for non-bookable facilities
    },

    HCC_COUNCIL_EMAIL: 'shaun.blagdon@gmail.com',
    
    // Limits
    EMAIL_RATE_LIMIT: 10,
    EMAIL_RATE_WINDOW_MS: 60000, 

    // UI Configuration
    UI: {
        STALL_COST: {
            FOOD: 50.00,
            GENERAL: 25.00,
            DEV: 90.00
        },
        STATUS_LIST: ['Pending', 'Confirmed', 'Rejected', 'Cancelled', 'On Hold', 'HCC Checks'],
        ALLOWED_TYPES: ["Dev", "Food", "Non-Food", "Attraction", "Barrier", "Ramp", "First Aid", "Beach", "Music", "Green", "Police", "Fire Engine", "Toilet"],
        STATUS_COLORS: {
            'Pending': 'bg-yellow-100 text-yellow-700',
            'Confirmed': 'bg-green-100 text-green-700',
            'Rejected': 'bg-red-100 text-red-700',
            'Cancelled': 'bg-gray-100 text-gray-700',
            'On Hold': 'bg-purple-100 text-purple-700',
            'HCC Checks': 'bg-orange-100 text-orange-700'
        }
    },

    // Supabase Credentials (Public/Anon)
    SUPABASE: {
        URL: "https://rsnxhuhibglieofikkpo.supabase.co",
        KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJzbnhodWhpYmdsaWVvZmlra3BvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2Nzg5MjcsImV4cCI6MjA4NTI1NDkyN30.QNrMVCc9FFdIAR4wRv6g4V4p2JA8pbCoaf8zLRuu0fw"
    }
};

/**
 * Get the current instance from localStorage or default to DEV.
 */
export function getCurrentInstance() {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('ESF_INSTANCE')) 
           ? localStorage.getItem('ESF_INSTANCE') 
           : 'DEV';
}

/**
 * Resolves the stall cost based on instance prefix or key.
 */
export function getStallCost(prefixOrKey) {
    const costs = CONFIG.UI.STALL_COST;
    const current = getCurrentInstance();
    
    if (prefixOrKey) {
        const p = prefixOrKey.toUpperCase();
        if (p.includes('FOOD') && !p.includes('NONFOOD')) return costs.FOOD;
        if (p.includes('NONFOOD') || p === 'GENERAL') return costs.GENERAL;
        if (p.includes('DEV')) return costs.DEV;
    }
    return costs[current] || costs.FOOD;
}
